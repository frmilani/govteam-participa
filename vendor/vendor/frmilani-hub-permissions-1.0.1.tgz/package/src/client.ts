/**
 * @frmilani/hub-permissions - Hub Permissions Client
 * Main client for spokes to interact with the Hub HPAC system.
 */

import type {
  HubPermissionsConfig,
  PermissionCheckRequest,
  PermissionCheckResult,
  BulkCheckResponse,
  ResolvedPermissions,
  AuditLogEntry,
  UserUnitsResponse,
} from './types'
import { PermissionCache } from './cache'

export class HubPermissions {
  private config: HubPermissionsConfig & { cacheTTL: number }
  private cache: PermissionCache
  private resolvedCache: Map<string, { data: ResolvedPermissions; expiresAt: number }> = new Map()

  constructor(config: HubPermissionsConfig) {
    this.config = {
      ...config,
      cacheTTL: config.cacheTTL ?? 300,
    }
    this.cache = new PermissionCache(this.config.cacheTTL)
  }

  /**
   * Check if a user can perform an action on a resource.
   * Uses local cache first, falls back to Hub API.
   */
  async check(
    userId: string,
    request: PermissionCheckRequest,
    organizationIdOverride?: string
  ): Promise<PermissionCheckResult> {
    const orgId = organizationIdOverride || this.config.organizationId
    if (!orgId) throw new Error('[hub-permissions] organizationId is required')

    const cacheKey = `${userId}:${orgId}:${request.resource}:${request.action}:${request.unitId || ''}:${request.resourceId || ''}`
    const cached = this.cache.get<PermissionCheckResult>(cacheKey)
    if (cached) return cached

    const response = await this.fetchFromHub<BulkCheckResponse>('/api/v1/permissions/check', {
      method: 'POST',
      body: JSON.stringify({
        userId,
        organizationId: orgId,
        checks: [request],
      }),
      headers: {
        'x-organization-id': orgId
      }
    })

    const result = response.results[0]
    if (result) {
      this.cache.set(cacheKey, result, response.cacheTTL)
    }
    return result
  }

  /**
   * Bulk check multiple permissions at once.
   */
  async checkBulk(
    userId: string,
    requests: PermissionCheckRequest[],
    organizationIdOverride?: string
  ): Promise<PermissionCheckResult[]> {
    const orgId = organizationIdOverride || this.config.organizationId
    if (!orgId) throw new Error('[hub-permissions] organizationId is required')

    const response = await this.fetchFromHub<BulkCheckResponse>('/api/v1/permissions/check', {
      method: 'POST',
      body: JSON.stringify({
        userId,
        organizationId: orgId,
        checks: requests,
      }),
      headers: {
        'x-organization-id': orgId
      }
    })

    // Cache individual results
    response.results.forEach((result, i) => {
      const req = requests[i]
      const cacheKey = `${userId}:${req.resource}:${req.action}:${req.unitId || ''}:${req.resourceId || ''}`
      this.cache.set(cacheKey, result, response.cacheTTL)
    })

    return response.results
  }

  /**
   * Resolve all effective permissions for a user.
   * Optionally filtered by spoke slug.
   * Results are cached by userId+spoke.
   */
  async resolve(userId: string, spoke?: string, organizationIdOverride?: string): Promise<ResolvedPermissions> {
    const orgId = organizationIdOverride || this.config.organizationId
    if (!orgId) throw new Error('[hub-permissions] organizationId is required')

    const cacheKey = `resolve:${userId}:${orgId}:${spoke || '*'}`
    const cached = this.resolvedCache.get(cacheKey)
    if (cached && cached.expiresAt > Date.now()) {
      return cached.data
    }

    const params = new URLSearchParams({
      userId,
      organizationId: orgId,
    })
    if (spoke) params.set('spoke', spoke)

    const resolved = await this.fetchFromHub<ResolvedPermissions>(
      `/api/v1/permissions/resolve?${params.toString()}`,
      {
        method: 'GET',
        headers: {
          'x-organization-id': orgId
        }
      }
    )

    this.resolvedCache.set(cacheKey, {
      data: resolved,
      expiresAt: Date.now() + (resolved.cacheTTL * 1000),
    })

    return resolved
  }

  /**
   * Send an audit log entry to the Hub.
   * Fire-and-forget by default.
   */
  async audit(entry: AuditLogEntry): Promise<void> {
    try {
      await this.fetchFromHub('/api/v1/permissions/audit', {
        method: 'POST',
        body: JSON.stringify(entry),
      })
    } catch (error) {
      console.error('[hub-permissions] Failed to send audit log:', error)
    }
  }

  /**
   * Fetch all units for a user in an organization.
   */
  async fetchUserUnits(userId: string, organizationIdOverride?: string): Promise<UserUnitsResponse> {
    const orgId = organizationIdOverride || this.config.organizationId
    if (!orgId) throw new Error('[hub-permissions] organizationId is required')

    const params = new URLSearchParams({
      userId,
      organizationId: orgId,
    })

    return await this.fetchFromHub<UserUnitsResponse>(
      `/api/v1/members/me/units?${params.toString()}`,
      {
        method: 'GET',
        headers: {
          'x-organization-id': orgId
        }
      }
    )
  }

  /**
   * Invalidate all cached permissions.
   * Call this when permissionVersion changes.
   */
  invalidateCache(): void {
    this.cache.clear()
    this.resolvedCache.clear()
  }

  /**
   * Alias for invalidateCache
   */
  clearCache(): void {
    this.invalidateCache()
  }

  /**
   * Check if cache needs invalidation based on permissionVersion.
   * Compare the version from the JWT token with the cached version.
   */
  shouldInvalidate(currentVersion: number, cachedVersion: number): boolean {
    return currentVersion !== cachedVersion
  }

  // ─── Internal ─────────────────────────────────────────

  private async fetchFromHub<T>(path: string, init: RequestInit): Promise<T> {
    const url = `${this.config.hubUrl}${path}`

    // Build headers based on available credentials
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...((init.headers as Record<string, string>) || {}),
    }

    if (this.config.apiKey) {
      headers['Authorization'] = `Bearer ${this.config.apiKey}`
      headers['x-api-key'] = this.config.apiKey
    }

    if (this.config.spokeId && this.config.spokeSecret) {
      headers['x-spoke-id'] = this.config.spokeId
      headers['x-spoke-secret'] = this.config.spokeSecret
    }

    if (this.config.organizationId) {
      headers['x-organization-id'] = this.config.organizationId
    }

    const response = await fetch(url, {
      ...init,
      headers,
    })

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'unknown' }))
      throw new Error(`[hub-permissions] API error ${response.status}: ${JSON.stringify(error)}`)
    }

    return response.json()
  }
}
