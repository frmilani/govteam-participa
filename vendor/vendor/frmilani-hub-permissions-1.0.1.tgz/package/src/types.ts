/**
 * @frmilani/hub-permissions - Type Definitions
 */

export interface HubPermissionsConfig {
  hubUrl: string
  apiKey?: string // Legacy API Key
  spokeId?: string // Modern Spoke ID (slug)
  spokeSecret?: string // Modern Spoke Secret
  organizationId?: string
  cacheTTL?: number // seconds, default 300
}

export interface PermissionCheckRequest {
  resource: string
  action: string
  resourceId?: string
  unitId?: string
  context?: Record<string, unknown>
}

export interface PermissionCheckResult {
  allowed: boolean
  fieldMask: string[] | null
  matchedPolicy?: string
  unitScope: string[] | null
  reason?: string
}

export interface BulkCheckResponse {
  results: PermissionCheckResult[]
  cacheKey: string
  cacheTTL: number
}

export interface EffectivePermission {
  resource: string
  actions: string[]
  fieldMask: string[] | null
  unitScope: string[] | null
  conditions: Record<string, unknown> | null
}

export interface DeniedResource {
  resource: string
  actions: string[]
  reason: string
}

export interface ResolvedPermissions {
  userId: string
  organizationId: string
  spoke?: string
  isSpoke?: boolean
  effectivePermissions: EffectivePermission[]
  deniedResources: DeniedResource[]
  version: number
  resolvedAt: string
  cacheTTL: number
}

export interface AuditLogEntry {
  userId: string
  organizationId: string
  unitId?: string
  action: string
  resource: string
  resourceId?: string
  outcome: 'ALLOWED' | 'DENIED' | 'ERROR'
  details?: Record<string, unknown>
  ipAddress?: string
  userAgent?: string
  spokeId?: string
}

export interface UserUnitsResponse {
  units: any[]
  hasGlobalAccess: boolean
}
