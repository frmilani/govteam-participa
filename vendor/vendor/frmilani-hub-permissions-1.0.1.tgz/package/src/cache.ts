/**
 * @frmilani/hub-permissions - In-Memory Permission Cache
 * Simple TTL-based cache for permission results.
 */

interface CacheEntry<T> {
  data: T
  expiresAt: number
}

export class PermissionCache {
  private store: Map<string, CacheEntry<unknown>> = new Map()
  private defaultTTL: number

  constructor(defaultTTLSeconds: number = 300) {
    this.defaultTTL = defaultTTLSeconds * 1000
  }

  get<T>(key: string): T | null {
    const entry = this.store.get(key)
    if (!entry) return null
    if (Date.now() > entry.expiresAt) {
      this.store.delete(key)
      return null
    }
    return entry.data as T
  }

  set<T>(key: string, data: T, ttlSeconds?: number): void {
    const ttl = ttlSeconds ? ttlSeconds * 1000 : this.defaultTTL
    this.store.set(key, {
      data,
      expiresAt: Date.now() + ttl,
    })
  }

  delete(key: string): void {
    this.store.delete(key)
  }

  clear(): void {
    this.store.clear()
  }

  size(): number {
    return this.store.size
  }

  /**
   * Remove all expired entries.
   * Call periodically to prevent memory leaks in long-running processes.
   */
  prune(): number {
    const now = Date.now()
    let pruned = 0
    this.store.forEach((entry, key) => {
      if (now > entry.expiresAt) {
        this.store.delete(key)
        pruned++
      }
    })
    return pruned
  }
}
