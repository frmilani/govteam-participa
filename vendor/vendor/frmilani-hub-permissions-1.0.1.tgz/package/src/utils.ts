/**
 * @frmilani/hub-permissions - Utility Functions
 * Field mask and unit scope helpers for Spokes.
 */

/**
 * Applies a field mask to a data object.
 * - Deny list: ["-cpf", "-salario"] → removes these fields
 * - Allow list: ["nome", "email"] → only keeps these fields
 * - Empty array or null → returns data unchanged
 */
export function applyFieldMask<T extends Record<string, unknown>>(
  data: T,
  mask: string[] | null | undefined
): Partial<T> {
  if (!mask || mask.length === 0) return data

  const denyFields = mask.filter(f => f.startsWith('-')).map(f => f.slice(1))
  const allowFields = mask.filter(f => !f.startsWith('-'))

  if (allowFields.length > 0) {
    const result: Partial<T> = {}
    for (const key of allowFields) {
      if (key in data) {
        (result as Record<string, unknown>)[key] = data[key]
      }
    }
    return result
  }

  const result = { ...data }
  for (const key of denyFields) {
    delete (result as Record<string, unknown>)[key]
  }
  return result
}

/**
 * Applies field mask to an array of objects.
 */
export function applyFieldMaskToArray<T extends Record<string, unknown>>(
  items: T[],
  mask: string[] | null | undefined
): Partial<T>[] {
  if (!mask || mask.length === 0) return items
  return items.map(item => applyFieldMask(item, mask))
}

/**
 * Filters a list of items by unit scope.
 * Only keeps items whose unitId is in the allowed scope.
 * If unitScope is null, all items pass (org-wide access).
 * 
 * @example
 * const filtered = filterByUnitScope(enquetes, permission.unitScope, 'unitId')
 */
export function filterByUnitScope<T>(
  items: T[],
  unitScope: string[] | null | undefined,
  unitIdField: keyof T = 'unitId' as keyof T
): T[] {
  if (!unitScope) return items // null = org-wide, no filtering
  return items.filter(item => {
    const itemUnitId = item[unitIdField]
    if (typeof itemUnitId !== 'string') return false
    return unitScope.includes(itemUnitId)
  })
}

/**
 * Checks if a specific unit ID is within the allowed scope.
 * Returns true if unitScope is null (org-wide access).
 */
export function isUnitInScope(
  unitId: string | null | undefined,
  unitScope: string[] | null | undefined
): boolean {
  if (!unitScope) return true // null = org-wide
  if (!unitId) return false
  return unitScope.includes(unitId)
}

/**
 * Extracts the spoke slug from a resource string.
 * e.g., "premio:enquete" → "premio"
 */
export function getSpokeFromResource(resource: string): string {
  return resource.split(':')[0]
}

/**
 * Checks if a resource pattern matches a target resource.
 * Supports wildcards: "*:*" matches everything, "premio:*" matches all premio resources.
 */
export function matchesResource(pattern: string, target: string): boolean {
  if (pattern === '*:*') return true
  if (pattern === target) return true

  const [patternSpoke, patternResource] = pattern.split(':')
  const [targetSpoke] = target.split(':')

  if (patternSpoke === targetSpoke && patternResource === '*') return true
  if (patternSpoke === '*' && patternResource === '*') return true

  return false
}
/**
 * Builds a Prisma-compatible where clause for unit scoping.
 */
export function buildUnitScopeWhere(
  unitScope: string[] | null | undefined
): { unitId?: { in: string[] } | null } {
  if (!unitScope) return {} // organization-wide
  return { unitId: { in: unitScope } }
}

/**
 * Narrows down the unit scope based on an active unit selected in the UI.
 */
export function narrowUnitScope(
  unitScope: string[] | null | undefined,
  activeUnitId: string | null | undefined
): string[] | null | undefined {
  if (!activeUnitId) return unitScope
  if (!unitScope) return [activeUnitId]
  if (unitScope.includes(activeUnitId)) return [activeUnitId]
  return unitScope
}

/**
 * Helper to extract the active unit ID from standard headers.
 */
export function getActiveUnitFromRequest(request: Request | any): string | null {
  if (typeof request.headers?.get === 'function') {
    return request.headers.get('x-active-unit-id') || null
  }
  return request.headers?.['x-active-unit-id'] || null
}
