/**
 * @frmilani/hub-permissions
 * HPAC Permission SDK for GovTeam Spokes
 * 
 * @example
 * import { HubPermissions, applyFieldMask, filterByUnitScope } from '@frmilani/hub-permissions'
 * 
 * const perms = new HubPermissions({
 *   hubUrl: process.env.HUB_URL!,
 *   apiKey: process.env.HUB_API_KEY!,
 *   organizationId: process.env.ORGANIZATION_ID!,
 * })
 * 
 * // Check a single permission
 * const result = await perms.check(userId, { resource: 'premio:enquete', action: 'update' })
 * if (!result.allowed) throw new ForbiddenError()
 * 
 * // Apply field mask to response data
 * const masked = applyFieldMask(enquete, result.fieldMask)
 * 
 * // Filter by unit scope
 * const scoped = filterByUnitScope(enquetes, result.unitScope, 'unitId')
 */

// Client
export { HubPermissions } from './client'

// Middleware
export { withPermission, withNextPermission } from './middleware'

// Utilities
export {
  applyFieldMask,
  applyFieldMaskToArray,
  filterByUnitScope,
  isUnitInScope,
  getSpokeFromResource,
  matchesResource,
  narrowUnitScope,
  buildUnitScopeWhere,
  getActiveUnitFromRequest,
} from './utils'

// Cache
export { PermissionCache } from './cache'

// Types
export type {
  HubPermissionsConfig,
  PermissionCheckRequest,
  PermissionCheckResult,
  BulkCheckResponse,
  EffectivePermission,
  DeniedResource,
  ResolvedPermissions,
  AuditLogEntry,
  UserUnitsResponse,
} from './types'
