/**
 * @frmilani/hub-permissions - Express/Next.js Middleware Helper
 * Provides withPermission() middleware for protecting routes.
 */

import type { HubPermissions } from './client'
import type { PermissionCheckResult } from './types'

/**
 * Creates a permission-checking middleware for Express-like frameworks.
 * 
 * @example
 * const guard = withPermission(hubPerms, 'premio:enquete', 'update')
 * app.put('/api/enquetes/:id', guard, handler)
 */
export function withPermission(
  client: HubPermissions,
  resource: string,
  action: string,
  options?: {
    getUserId?: (req: any) => string | undefined
    getUnitId?: (req: any) => string | undefined
    getResourceId?: (req: any) => string | undefined
    onDenied?: (req: any, res: any, result: PermissionCheckResult) => void
  }
) {
  return async function permissionMiddleware(req: any, res: any, next: any) {
    const getUserId = options?.getUserId || ((r: any) => r.user?.id || r.userId)
    const getUnitId = options?.getUnitId || ((r: any) => r.query?.unitId || r.params?.unitId)
    const getResourceId = options?.getResourceId || ((r: any) => r.params?.id)

    const userId = getUserId(req)
    if (!userId) {
      return res.status(401).json({ error: 'unauthorized', message: 'User ID not found in request' })
    }

    try {
      const result = await client.check(userId, {
        resource,
        action,
        unitId: getUnitId(req),
        resourceId: getResourceId(req),
      })

      if (!result.allowed) {
        if (options?.onDenied) {
          return options.onDenied(req, res, result)
        }
        return res.status(403).json({
          error: 'forbidden',
          resource,
          action,
          reason: result.reason,
        })
      }

      // Attach permission result to request for downstream use
      req.permission = result
      req.fieldMask = result.fieldMask
      req.unitScope = result.unitScope

      next()
    } catch (error) {
      console.error('[hub-permissions] Middleware error:', error)
      return res.status(500).json({ error: 'permission_check_failed' })
    }
  }
}

/**
 * Next.js API Route wrapper for permission checking.
 * 
 * @example
 * export const PUT = withNextPermission(hubPerms, 'premio:enquete', 'update', async (req, ctx) => {
 *   // ctx.permission has the check result
 *   return NextResponse.json({ ok: true })
 * })
 */
export function withNextPermission(
  client: HubPermissions,
  resource: string,
  action: string,
  handler: (req: Request, ctx: { permission: PermissionCheckResult; userId: string }) => Promise<Response>,
  options?: {
    getUserId?: (req: Request) => string | undefined
  }
) {
  return async function nextPermissionHandler(req: Request): Promise<Response> {
    const getUserId = options?.getUserId || (() => {
      // Try to extract from headers (set by auth middleware)
      return req.headers.get('x-user-id') || undefined
    })

    const userId = getUserId(req)
    if (!userId) {
      return new Response(JSON.stringify({ error: 'unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' },
      })
    }

    try {
      const result = await client.check(userId, { resource, action })

      if (!result.allowed) {
        return new Response(JSON.stringify({
          error: 'forbidden',
          resource,
          action,
          reason: result.reason,
        }), {
          status: 403,
          headers: { 'Content-Type': 'application/json' },
        })
      }

      return handler(req, { permission: result, userId })
    } catch (error) {
      console.error('[hub-permissions] Next.js middleware error:', error)
      return new Response(JSON.stringify({ error: 'permission_check_failed' }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      })
    }
  }
}
