# @govteam/hub-permissions

HPAC Permission SDK for GovTeam Spokes. Provides a simple API to check, resolve, cache, and apply permissions from the Hub.

## Installation

```bash
npm install @govteam/hub-permissions
# or link locally
npm link ../packages/hub-permissions
```

## Quick Start

```typescript
import { HubPermissions, applyFieldMask, filterByUnitScope } from '@govteam/hub-permissions'

const perms = new HubPermissions({
  hubUrl: process.env.HUB_URL!,
  apiKey: process.env.HUB_API_KEY!,
  organizationId: process.env.ORGANIZATION_ID!,
  cacheTTL: 300, // 5 min (default)
})

// Check a single permission
const result = await perms.check(userId, {
  resource: 'premio:enquete',
  action: 'update',
  unitId: 'unit-abc',
})

if (!result.allowed) {
  return res.status(403).json({ error: 'forbidden', reason: result.reason })
}

// Apply field mask to hide sensitive fields
const safeData = applyFieldMask(enquete, result.fieldMask)

// Filter query results by unit scope
const scopedItems = filterByUnitScope(allEnquetes, result.unitScope, 'unitId')
```

## Express Middleware

```typescript
import { withPermission } from '@govteam/hub-permissions'

app.put('/api/enquetes/:id',
  withPermission(perms, 'premio:enquete', 'update'),
  async (req, res) => {
    // req.permission, req.fieldMask, req.unitScope available
    const data = applyFieldMask(req.body, req.fieldMask)
    // ...
  }
)
```

## Next.js API Route

```typescript
import { withNextPermission } from '@govteam/hub-permissions'

export const PUT = withNextPermission(perms, 'premio:enquete', 'update',
  async (req, { permission, userId }) => {
    return NextResponse.json({ ok: true })
  }
)
```

## Bulk Resolution (Startup)

```typescript
// At spoke startup, resolve all permissions for the current user
const resolved = await perms.resolve(userId, 'premio')

// resolved.effectivePermissions[] - what the user CAN do
// resolved.deniedResources[] - what is explicitly DENIED
// resolved.version - permissionVersion for cache invalidation
```

## Cache Invalidation

```typescript
// Compare JWT permissionVersion with cached version
if (perms.shouldInvalidate(jwtPermissionVersion, cachedVersion)) {
  perms.invalidateCache()
}
```

## API Reference

### `HubPermissions`
- `check(userId, request)` - Check single permission
- `checkBulk(userId, requests)` - Check multiple permissions
- `resolve(userId, spoke?)` - Resolve all effective permissions
- `audit(entry)` - Send audit log (fire-and-forget)
- `invalidateCache()` - Clear all cached permissions
- `shouldInvalidate(current, cached)` - Check if cache is stale

### Utilities
- `applyFieldMask(data, mask)` - Apply field-level access control
- `applyFieldMaskToArray(items, mask)` - Apply to array
- `filterByUnitScope(items, scope, field)` - Filter by unit hierarchy
- `isUnitInScope(unitId, scope)` - Check single unit
- `matchesResource(pattern, target)` - Resource pattern matching

### Middleware
- `withPermission(client, resource, action, options?)` - Express middleware
- `withNextPermission(client, resource, action, handler, options?)` - Next.js wrapper
